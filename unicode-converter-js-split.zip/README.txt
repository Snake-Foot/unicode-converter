Unicode Converter JS split

config.js      DOM references, helpers, timing
fonts.js       Unicode range/font mapping and font loading
glyph-check.js Canvas glyph checks, blank/missing detection, scaling
converter.js   char<->Unicode, parser, history, rendering
random.js      secure random generation and filters
daily.js       JST/daily JSON/SVG, 0g0.org research link
scope.js       Unicode Scope and copy/long-press handling
main.js        event listeners and startup

Important: do not load old script.js together with these files. Keep it as a backup until the split version is verified.
